package com.automation.engine

import com.google.ai.edge.litertlm.Tool
import com.google.ai.edge.litertlm.ToolParam
import com.google.ai.edge.litertlm.ToolSet

class AppActionToolSet(private val accessibilityService: SmartAccessibilityService) : ToolSet {

    @Tool(description = "Scrolls the screen down. Use this when the user asks to swipe, scroll down, or bypass sponsored ads on YouTube.")
    fun scrollDown() {
        accessibilityService.performScrollDown()
    }

    @Tool(description = "Performs a long press gesture on the screen at specified coordinates to zoom into an image in the gallery.")
    fun zoomAndHold(
        @ToolParam(description = "The X coordinate on the screen, e.g., 500.0") x: Double,
        @ToolParam(description = "The Y coordinate on the screen, e.g., 1000.0") y: Double
    ) {
        accessibilityService.performZoomHoldLogic(x.toFloat(), y.toFloat())
    }

    @Tool(description = "Starts the sequential scene-by-scene automation queue. Use this when the user wants to start generating scenes or run the script queue.")
    fun startSceneQueue() {
        accessibilityService.startSequentialSceneAutomation()
    }
}
