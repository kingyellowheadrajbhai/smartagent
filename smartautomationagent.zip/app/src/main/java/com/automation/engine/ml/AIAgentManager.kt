package com.automation.engine.ml

import android.content.Context
import android.util.Log
import com.google.ai.edge.litertlm.*
import com.automation.engine.AppActionToolSet
import com.automation.engine.SmartAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.URL

object AIAgentManager {
    private const val TAG = "AIAgentManager"
    private const val MODEL_NAME = "qwen_0.5b_chat.litertlm"
    private const val MODEL_DOWNLOAD_URL = "https://huggingface.co/litert-community/Qwen1.5-0.5B-Chat-LiteRT-LM/resolve/main/qwen_0.5b_chat.litertlm"

    private var engine: Engine? = null
    private var conversation: Conversation? = null

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_NAME)
    }

    fun isModelDownloaded(context: Context): Boolean {
        return getModelFile(context).exists()
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        val destination = getModelFile(context)
        try {
            Log.d(TAG, "डाउनलोड शुरू हो रहा है: $MODEL_DOWNLOAD_URL")
            val url = URL(MODEL_DOWNLOAD_URL)
            val connection = url.openConnection()
            connection.connect()
            val fileLength = connection.contentLength

            val input = url.openStream()
            val output = FileOutputStream(destination)

            val data = ByteArray(4096)
            var total: Long = 0
            var count: Int
            while (input.read(data).also { count = it }!= -1) {
                total += count
                if (fileLength > 0) {
                    val progress = (total * 100 / fileLength).toInt()
                    withContext(Dispatchers.Main) {
                        onProgress(progress)
                    }
                }
                output.write(data, 0, count)
            }
            output.flush()
            output.close()
            input.close()
            Log.d(TAG, "डाउनलोड सफलतापूर्वक समाप्त!")
            true
        } catch (e: Exception) {
            Log.e(TAG, "डाउनलोड फेल हो गया: ${e.message}")
            if (destination.exists()) destination.delete()
            false
        }
    }

    suspend fun initializeAIAgent(context: Context, service: SmartAccessibilityService): Boolean = withContext(Dispatchers.IO) {
        if (engine!= null) return@withContext true
        val modelFile = getModelFile(context)
        if (!modelFile.exists()) return@withContext false

        try {
            Log.d(TAG, "LiteRT-LM इंजन लोड हो रहा है...")
            val engineConfig = EngineConfig(
                modelPath = modelFile.absolutePath,
                backend = Backend.GPU(),
                cacheDir = context.cacheDir.absolutePath
            )
            
            val localEngine = Engine(engineConfig)
            localEngine.initialize()
            engine = localEngine

            val conversationConfig = ConversationConfig(
                systemInstruction = Contents.of("तुम राज भाई के पर्सनल AI एजेंट हो। तुम यूज़र से बात कर सकते हो और ज़रूरत पड़ने पर फोन की स्क्रीन को कंट्रोल करने के लिए टूल्स का इस्तेमाल कर सकते हो।"),
                tools = listOf(tool(AppActionToolSet(service)))
            )
            conversation = localEngine.createConversation(conversationConfig)
            Log.d(TAG, "LiteRT-LM का ऑफलाइन दिमाग पूरी तरह एक्टिवेट हो गया है! 🟢")
            true
        } catch (e: Exception) {
            Log.e(TAG, "इंजन चालू करने में एरर: ${e.message}")
            false
        }
    }

    suspend fun sendMessageToAI(message: String): String = withContext(Dispatchers.IO) {
        val activeConversation = conversation?: return@withContext "एआई का दिमाग अभी लोड नहीं हुआ है, राज भाई!"
        try {
            val response = activeConversation.sendMessage(message)
            response.text?: "कोई जवाब नहीं मिला।"
        } catch (e: Exception) {
            Log.e(TAG, "AI चैट एरर: ${e.message}")
            "माफ़ करना राज भाई, समझने में कुछ एरर आ रही है।"
        }
    }
}
