// File: PromptDatabase.kt
package com.automation.engine.db

import android.content.Context
import androidx.room.*
import java.io.Serializable

// टाइप-सेफ कतार प्रबंधन के लिए एनम क्लास
enum class SceneStatus {
    PENDING,
    PROCESSING,
    COMPLETED,
    FAILED
}

// एनम को डेटाबेस में सेव और रीड करने के लिए कनवर्टर क्लास
class DatabaseConverters {
    @TypeConverter
    fun fromStatus(status: SceneStatus): String {
        return status.name
    }

    @TypeConverter
    fun toStatus(status: String): SceneStatus {
        return try {
            SceneStatus.valueOf(status)
        } catch (e: Exception) {
            SceneStatus.PENDING
        }
    }
}

// 1. प्रॉम्प्ट इतिहास सहेजने की तालिका
@Entity(tableName = "prompt_table")
data class PromptEntity(
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    val scriptName: String,
    val generatedPrompt: String,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Dao
interface PromptDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrompt(prompt: PromptEntity)

    @Query("SELECT * FROM prompt_table ORDER BY id DESC LIMIT 1")
    suspend fun getLatestPrompt(): PromptEntity?
    
    @Query("DELETE FROM prompt_table")
    suspend fun clearAll()
}

// 2. नए सीन-दर-सीन सैनिक कतार तालिका
@Entity(tableName = "scenes_table")
data class SceneEntity(
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    val sceneCode: String,
    val sceneTitle: String,
    val rawContent: String,
    var generatedPrompt: String = "",
    val episodeNumber: Int = 2,
    var status: SceneStatus = SceneStatus.PENDING
) : Serializable

@Dao
interface SceneDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScenes(scenes: List<SceneEntity>)

    @Query("SELECT * FROM scenes_table WHERE status = 'PENDING' ORDER BY id ASC LIMIT 1")
    suspend fun getNextPendingScene(): SceneEntity?

    @Update
    suspend fun updateScene(scene: SceneEntity)

    @Query("UPDATE scenes_table SET status = 'PENDING' WHERE episodeNumber = :episodeNum")
    suspend fun resetEpisodeQueue(episodeNum: Int)

    @Query("DELETE FROM scenes_table")
    suspend fun clearQueue()
}

// 🚀 THE ULTIMATE K2 COMPILER FIX: सही ऐरे सिंटैक्स [Entity1, Entity2]
@Database(
    entities =, 
    version = 3,
    exportSchema = false
)
@TypeConverters(DatabaseConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun promptDao(): PromptDao
    abstract fun sceneDao(): SceneDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "automation_database"
                )
             .fallbackToDestructiveMigration()
             .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
