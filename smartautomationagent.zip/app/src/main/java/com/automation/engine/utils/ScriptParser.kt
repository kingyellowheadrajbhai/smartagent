package com.automation.engine.utils

import com.automation.engine.db.SceneEntity
import com.automation.engine.db.SceneStatus

object ScriptParser {

    fun parseScript(fullScript: String): List<SceneEntity> {
        val sceneList = mutableListOf<SceneEntity>()
        val rawBlocks = fullScript.split("---")
        
        for (block in rawBlocks) {
            val trimmedBlock = block.trim()
            if (trimmedBlock.isEmpty()) continue
            
            val lines = trimmedBlock.lines()
            val firstLine = lines.first().trim()
            
            val regex = Regex("""^(C-\d+(?:\.\d+)?)(?:\s*—\s*(.*))?""")
            val matchResult = regex.find(firstLine)
            
            val sceneCode = matchResult?.groupValues?.get(1)?: "C-Unknown"
            val sceneTitle = matchResult?.groupValues?.get(2)?.trim()?: ""
            
            val rawContent = lines.drop(1).joinToString("\n").trim()
            
            if (rawContent.isNotEmpty()) {
                sceneList.add(
                    SceneEntity(
                        sceneCode = sceneCode,
                        sceneTitle = sceneTitle,
                        rawContent = rawContent,
                        status = SceneStatus.PENDING
                    )
                )
            }
        }
        return sceneList
    }
}
