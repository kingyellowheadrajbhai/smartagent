package com.automation.engine.utils

import com.automation.engine.db.SceneEntity

object ScriptParser {

    /**
     * यह फंक्शन पूरी स्क्रिप्ट स्ट्रिंग को पार्स करके SceneEntity की लिस्ट बनाएगा
     */
    fun parseScript(fullScript: String): List<SceneEntity> {
        val sceneList = mutableListOf<SceneEntity>()
        
        // स्क्रिप्ट को "---" से अलग-अलग सीन ब्लॉक्स में विभाजित करना
        val rawBlocks = fullScript.split("---")
        
        for (block in rawBlocks) {
            val trimmedBlock = block.trim()
            if (trimmedBlock.isEmpty()) continue
            
            val lines = trimmedBlock.lines()
            val firstLine = lines.first().trim()
            
            // Regex: "C-1 — Gaon Ke Bahar" या "C-7.5" जैसे पैटर्न्स को पकड़ने के लिए
            val regex = Regex("""^(C-\d+(?:\.\d+)?)(?:\s*—\s*(.*))?""")
            val matchResult = regex.find(firstLine)
            
            val sceneCode = matchResult?.groupValues?.get(1) ?: "C-Unknown"
            val sceneTitle = matchResult?.groupValues?.get(2)?.trim() ?: ""
            
            // पहली लाइन (हेडर) को छोड़कर बाकी लाइन्स डायलॉग और विवरण हैं
            val rawContent = lines.drop(1).joinToString("\n").trim()
            
            if (rawContent.isNotEmpty()) {
                sceneList.add(
                    SceneEntity(
                        sceneCode = sceneCode,
                        sceneTitle = sceneTitle,
                        rawContent = rawContent,
                        status = "PENDING"
                    )
                )
            }
        }
        return sceneList
    }
}
