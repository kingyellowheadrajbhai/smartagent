package com.automation.engine

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var tvServiceStatus: TextView
    private lateinit var btnToggleService: Button
    private lateinit var etConfidence: EditText
    private lateinit var etDelay: EditText
    private lateinit var btnSaveSettings: Button
    private lateinit var btnTriggerZoom: Button
    private lateinit var btnTriggerScroll: Button
    
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sharedPreferences = getSharedPreferences("AutomationSettings", Context.MODE_PRIVATE)

        // UI एलिमेंट्स को बाइंड करना
        tvServiceStatus = findViewById(R.id.tv_service_status)
        btnToggleService = findViewById(R.id.btn_toggle_service)
        etConfidence = findViewById(R.id.et_confidence)
        etDelay = findViewById(R.id.et_delay)
        btnSaveSettings = findViewById(R.id.btn_save_settings)
        btnTriggerZoom = findViewById(R.id.btn_trigger_zoom)
        btnTriggerScroll = findViewById(R.id.btn_trigger_scroll)

        // सेटिंग्स को लोड करना
        loadSavedSettings()

        // 1. सर्विस सेटिंग्स खोलने के लिए बटन क्लिक
        btnToggleService.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
        }

        // 2. सेटिंग्स सेव और ब्रॉडकास्ट करना
        btnSaveSettings.setOnClickListener {
            val confidence = etConfidence.text.toString().toFloatOrNull()?: 0.65f
            val delay = etDelay.text.toString().toIntOrNull()?: 400

            sharedPreferences.edit().apply {
                putFloat("confidence", confidence)
                putInt("delay", delay)
                apply()
            }

            // सर्विस को सूचित करें कि सेटिंग्स बदल गई हैं
            val intent = Intent("com.automation.engine.UPDATE_SETTINGS").apply {
                putExtra("confidence", confidence)
                putExtra("delay", delay)
            }
            sendBroadcast(intent)
            Toast.makeText(this, "सेटिंग्स सेव हो गईं और इंजन अपडेट हो गया!", Toast.LENGTH_SHORT).show()
        }

        // 3. गैलरी ज़ूम कमांड भेजना
        btnTriggerZoom.setOnClickListener {
            if (isAccessibilityServiceEnabled()) {
                val intent = Intent("com.automation.engine.TRIGGER_ZOOM")
                sendBroadcast(intent)
                Toast.makeText(this, "गैलरी ज़ूम टेस्ट सिग्नल भेजा गया", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "कृपया पहले एक्सेसिबिलिटी सर्विस सक्षम करें!", Toast.LENGTH_LONG).show()
            }
        }

        // 4. यूट्यूब स्क्रॉल कमांड भेजना
        btnTriggerScroll.setOnClickListener {
            if (isAccessibilityServiceEnabled()) {
                val intent = Intent("com.automation.engine.TRIGGER_SCROLL")
                sendBroadcast(intent)
                Toast.makeText(this, "यूट्यूब स्क्रॉल टेस्ट सिग्नल भेजा गया", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "कृपया पहले एक्सेसिबिलिटी सर्विस सक्षम करें!", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // सर्विस की वर्तमान स्थिति को अपडेट करना
        if (isAccessibilityServiceEnabled()) {
            tvServiceStatus.text = "सर्विस स्थिति: चालू (ACTIVE)🟢"
            tvServiceStatus.setTextColor(android.graphics.Color.GREEN)
            btnToggleService.text = "सर्विस बंद करें (Settings)"
        } else {
            tvServiceStatus.text = "सर्विस स्थिति: बंद (DISABLED)🔴"
            tvServiceStatus.setTextColor(android.graphics.Color.RED)
            btnToggleService.text = "सर्विस चालू करें (Settings)"
        }
    }

    private fun loadSavedSettings() {
        val confidence = sharedPreferences.getFloat("confidence", 0.65f)
        val delay = sharedPreferences.getInt("delay", 400)
        etConfidence.setText(confidence.toString())
        etDelay.setText(delay.toString())
    }

    // एक्सेसिबिलिटी सर्विस सक्षम है या नहीं जांचने की विधि
    private fun isAccessibilityServiceEnabled(): Boolean {
        val expectedComponentName = "$packageName/${SmartAccessibilityService::class.java.name}"
        val enabledServicesSetting = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )?: return false
        
        val colonSplitter = TextUtils.SimpleStringSplitter(':')
        colonSplitter.setString(enabledServicesSetting)
        while (colonSplitter.hasNext()) {
            val componentNameString = colonSplitter.next()
            // 🚀 THE FIX: कोटलिन का सही केस-इग्नोर सिंटैक्स
            if (componentNameString.equals(expectedComponentName, ignoreCase = true)) {
                return true
            }
        }
        return false
    }
}
