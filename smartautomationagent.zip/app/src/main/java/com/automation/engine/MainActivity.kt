package com.automation.engine

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.lifecycleScope
import com.automation.engine.db.AppDatabase
import com.automation.engine.ml.AIAgentManager
import com.automation.engine.utils.ScriptParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"
    
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var btnMenu: ImageView
    private lateinit var btnSettings: ImageView
    private lateinit var etMessage: EditText
    private lateinit var btnSend: ImageView
    private lateinit var chatContainer: LinearLayout
    private lateinit var chatScrollView: ScrollView
    private lateinit var btnNewChat: Button
    private lateinit var btnUploadScript: Button
    private lateinit var btnClearHistory: Button
    private lateinit var historyContainer: LinearLayout

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sharedPreferences = getSharedPreferences("AutomationSettings", Context.MODE_PRIVATE)

        // UI बाइंडिंग
        drawerLayout = findViewById(R.id.drawer_layout)
        btnMenu = findViewById(R.id.btn_menu)
        btnSettings = findViewById(R.id.btn_settings)
        etMessage = findViewById(R.id.et_message)
        btnSend = findViewById(R.id.btn_send)
        chatContainer = findViewById(R.id.chat_container)
        chatScrollView = findViewById(R.id.chat_scroll_view)
        btnNewChat = findViewById(R.id.btn_new_chat)
        btnUploadScript = findViewById(R.id.btn_upload_script)
        btnClearHistory = findViewById(R.id.btn_clear_history)
        historyContainer = findViewById(R.id.history_container)

        // हैमबर्गर मेनू
        btnMenu.setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }

        // सेटिंग्स पॉपअप
        btnSettings.setOnClickListener {
            openSmartSettingsDialog()
        }

        // नया चैट
        btnNewChat.setOnClickListener {
            chatContainer.removeAllViews()
            addMessageToChat("नमस्ते राज भाई! मैं आपका 0.5B AI एजेंट हूँ। आज क्या कमांड रन करनी है?", false)
            drawerLayout.closeDrawer(GravityCompat.START)
        }

        // 🚀 स्क्रिप्ट अपलोड और पार्सिंग पॉपअप
        btnUploadScript.setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            openUploadScriptDialog()
        }

        // संदेश भेजना (Talk to AI)
        btnSend.setOnClickListener {
            val message = etMessage.text.toString().trim()
            if (message.isNotEmpty()) {
                addMessageToChat(message, true)
                etMessage.setText("")

                lifecycleScope.launch {
                    val aiResponse = AIAgentManager.sendMessageToAI(message)
                    withContext(Dispatchers.Main) {
                        addMessageToChat(aiResponse, false)
                    }
                }
            }
        }

        addMessageToChat("सिस्टम रेडी है। 0.5B AI दिमाग लोड हो रहा है...", false)
        
        // 🚀 ऑफलाइन दिमाग चेक और डाउनलोड लॉजिक
        lifecycleScope.launch {
            if (!AIAgentManager.isModelDownloaded(this@MainActivity)) {
                Toast.makeText(this@MainActivity, "एआई दिमाग डाउनलोड हो रहा है...", Toast.LENGTH_LONG).show()
                val success = AIAgentManager.downloadModel(this@MainActivity) { progress ->
                    Log.d(TAG, "Download Progress: $progress%")
                }
                if (success) {
                    Toast.makeText(this@MainActivity, "दिमाग सफलतापूर्वक डाउनलोड हो गया!", Toast.LENGTH_SHORT).show()
                    initializeBrain()
                } else {
                    Toast.makeText(this@MainActivity, "डाउनलोड फेल! इंटरनेट चेक करें।", Toast.LENGTH_LONG).show()
                }
            } else {
                initializeBrain()
            }
        }
    }

    private fun addMessageToChat(message: String, isUser: Boolean) {
        val textView = TextView(this).apply {
            text = message
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(40, 24, 40, 24)
            
            val drawable = GradientDrawable().apply {
                cornerRadius = 24f
                setColor(if (isUser) Color.parseColor("#005C4B") else Color.parseColor("#2A2A2A"))
            }
            background = drawable

            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = if (isUser) Gravity.END else Gravity.START
                setMargins(0, 8, 0, 16)
                marginEnd = if (isUser) 0 else 100
                marginStart = if (isUser) 100 else 0
            }
        }
        chatContainer.addView(textView)
        chatScrollView.post { chatScrollView.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    // 🚀 स्क्रिप्ट अपलोड संवाद पेटिका
    private fun openUploadScriptDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(60, 40, 60, 40)
            setBackgroundColor(Color.parseColor("#1E1E1E"))
        }

        val scriptTitle = TextView(this).apply { 
            text = "अपनी सीन-दर-सीन स्क्रिप्ट यहाँ पेस्ट करें:"
            setTextColor(Color.LTGRAY)
            textSize = 16f
        }
        
        val scriptInput = EditText(this).apply {
            hint = "C-1 — Gaon Ke Bahar\n...\n---\nC-2..."
            setHintTextColor(Color.GRAY)
            gravity = Gravity.TOP or Gravity.START
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or java.lang.Object() // Multi-line
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                400
            )
        }

        layout.addView(scriptTitle)
        layout.addView(scriptInput)

        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
          .setTitle("स्क्रिप्ट कतार लोडर")
          .setView(layout)
          .setPositiveButton("पार्स और शुरू करें") { _, _ ->
                val scriptText = scriptInput.text.toString().trim()
                if (scriptText.isNotEmpty()) {
                    lifecycleScope.launch(Dispatchers.IO) {
                        val db = AppDatabase.getDatabase(this@MainActivity)
                        val sceneDao = db.sceneDao()
                        
                        sceneDao.clearQueue()
                        val parsedScenes = ScriptParser.parseScript(scriptText)
                        if (parsedScenes.isNotEmpty()) {
                            sceneDao.insertScenes(parsedScenes)
                            
                            // वायरलेस संकेत भेजें
                            val intent = Intent("com.automation.engine.TRIGGER_QUEUE")
                            sendBroadcast(intent)
                            
                            withContext(Dispatchers.Main) {
                                Toast.makeText(this@MainActivity, "${parsedScenes.size} सीन्स सफलता से लोड हो गए।", Toast.LENGTH_LONG).show()
                                addMessageToChat("सिस्टम: ${parsedScenes.size} सीन्स रूम डेटाबेस में कतारबद्ध हो गए हैं। ऑफलाइन स्वचालन प्रारंभ हो गया है! ⚡", false)
                            }
                        } else {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(this@MainActivity, "स्क्रिप्ट पार्स करने में त्रुटि!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }
          .setNegativeButton("रद्द करें", null)
          .show()
    }

    private fun openSmartSettingsDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(60, 40, 60, 40)
            setBackgroundColor(Color.parseColor("#1E1E1E"))
        }

        val confTitle = TextView(this).apply { text = "YOLO Confidence Score (0.1 - 1.0)"; setTextColor(Color.LTGRAY) }
        val confInput = EditText(this).apply {
            setText(sharedPreferences.getFloat("confidence", 0.65f).toString())
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }

        val delayTitle = TextView(this).apply { text = "\nScroll Delay ms"; setTextColor(Color.LTGRAY) }
        val delayInput = EditText(this).apply {
            setText(sharedPreferences.getInt("delay", 400).toString())
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_NUMBER
        }

        layout.addView(confTitle)
        layout.addView(confInput)
        layout.addView(delayTitle)
        layout.addView(delayInput)

        val dialog = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
         .setTitle("इंजन सेटिंग्स")
         .setView(layout)
         .setPositiveButton("सेव करें") { _, _ ->
                val conf = confInput.text.toString().toFloatOrNull()?: 0.65f
                val del = delayInput.text.toString().toIntOrNull()?: 400
                
                sharedPreferences.edit().apply {
                    putFloat("confidence", conf)
                    putInt("delay", del)
                    apply()
                }

                val intent = Intent("com.automation.engine.UPDATE_SETTINGS").apply {
                    putExtra("confidence", conf)
                    putExtra("delay", del)
                }
                sendBroadcast(intent)
            }
         .setNegativeButton("रद्द करें", null)
         .create()

        dialog.show()
    }

    private fun initializeBrain() {
        if (isAccessibilityServiceEnabled()) {
            lifecycleScope.launch {
                Log.d(TAG, "एक्सेसिबिलिटी सर्विस सक्रिय है। एआई दिमाग रेडी है!")
                withContext(Dispatchers.Main) {
                    addMessageToChat("0.5B AI दिमाग लोड हो गया है! अब आप चैट कर सकते हैं।", false)
                }
            }
        } else {
            addMessageToChat("⚠️ एआई टूल्स को चलाने के लिए पहले सेटिंग्स से 'Accessibility Service' चालू करें!", false)
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expectedComponentName = "$packageName/${SmartAccessibilityService::class.java.name}"
        val enabledServicesSetting = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )?: return false
        
        val colonSplitter = TextUtils.SimpleStringSplitter(':')
        colonSplitter.setString(enabledServicesSetting)
        while (colonSplitter.hasNext()) {
            val componentNameString = colonSplitter.next()
            if (componentNameString.equals(expectedComponentName, ignoreCase = true)) {
                return true
            }
        }
        return false
    }
}
