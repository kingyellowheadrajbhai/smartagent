package com.raj.smartagent

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.raj.smartagent.workers.ResearchWorker

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Yeh line dimaag ko aapka banaya hua chehra (UI) pehnati hai!
        setContentView(R.layout.activity_main)
        
        // App khulte hi hum apna kaam (Research) shuru kar denge
        startResearch()
    }

    private fun startResearch() {
        // Work request create karna
        val researchRequest = OneTimeWorkRequestBuilder<ResearchWorker>().build()
        
        // Manager ko order dena
        WorkManager.getInstance(this).enqueue(researchRequest)
        
        println("Research task triggered by MainActivity!")
    }
}
